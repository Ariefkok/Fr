# -*- coding: utf-8 -*- 
from linepy  import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from urllib.parse import urlencode
from tmp.MySplit import *
from random import randint
from Naked.toolshed.shell import execute_js
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2

cl = LINE("dajjalkiller005@gmail.com","dajjal005")
cl.log("Auth Token : " + str(cl.authToken))

oepoll = OEPoll(cl)
print("---ᴄᴀʟᴏɴ ᴀʟᴍᴀʀʜᴜᴍ™ LOGIN SUCCES---")
mid = cl.getProfile().mid
settings = {
	"batasfast":0.004999,
	"keyCommand":"",
	"Gname":""
	}
status = 6
wait = {
	"Blacklist":[],
	"mode":False,
	"autojoin":True
	}
admin = ["u3f9c3061f8e7a7c4e07d5f6be08b9339"]
Bots = [mid]
botlist = [cl]
mulai = time.time()
helpM = """╭━━━━━━━━━━━━━╮
┃─✥SIMPLE COMMAND✥─  ┃
╰━━━━━━━━━━━━━╯
╭━━━━━━━━━━━━━╮
┃•Sp                                             
┃•Cuy                                  
┃•Tium @                                                        
┃•Cb                                                  
┃•Cl/Ki/Kk/Kc/Kd-gasgrup (num)
┃•Spin @name Gc@Jumlah@mid
┃•Opengc (num)
┃•,  (invite bot via qr)          
┃•Lepall
┃•Xname
┃•Glist
┃•Out                                            
┃•Restart                  
╰━━━━━━━━━━━━━╯"""

for bottt in botlist:
    for bott in Bots:
        try:
            bottt.findAndAddContactsByMid(bott)
        except:
            pass

def bot(op):
        global time
        global ast
        global groupParam
        global multiprocessing
        global subprocess
        global threading
        try:
            if op.type == 0:
                return

            if op.type == 19:
             if op.param3 in Bots:
              if op.param2 not in Bots and op.param2 not in admin:
              	invite = threading.Thread(target=bkp, args=(op.param1,op.param3)).start()
              	tampol = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()
              	input = threading.Thread(target=black, args=(op.param2,)).start()
             if op.param3 in admin:
              if op.param2 not in Bots and op.param2 not in admin:
              	input = threading.Thread(target=black, args=(op.param2,)).start()
              	invite2 = threading.Thread(target=bkpo, args=(op.param1,op.param3)).start()
              	tampol = threading.Thread(target=cium, args=(op.param1, op.param2)).start()

            if op.type == 13:
                if op.param3 in wait["Blacklist"]:
                	if op.param2 not in Bots and op.param2 not in admin:
                	    input2 = threading.Thread(target=black, args=(op.param2,)).start()
                	    batalin = threading.Thread(target=ccl, args=(op.param1, wait["Blacklist"])).start()
                	    tampol = threading.Thread(target=cium, args=(op.param1, op.param2)).start()

            if op.type == 32:
                if op.param3 in Bots:
                	if op.param2 not in Bots and op.param2 not in admin:
                	    input2 = threading.Thread(target=black, args=(op.param2,)).start()
                	    undang = threading.Thread(target=bkp, args=(op.param1,op.param3)).start()
                	    sikat2 = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()

            if op.type == 11:
                if wait["mode"] == True:
                	if op.param2 not in Bots and op.param2 not in admin:
                	    sikat = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()
                	    input3 = threading.Thread(target=black, args=(op.param2,)).start()
                	    kunci = threading.Thread(target=lockunicode, args=(op.param1,)).start()

            if op.type == 17:
                if op.param2 in wait["Blacklist"]:
                    kunci2 = threading.Thread(target=lockqr, args=(op.param1,)).start()
                    pentung = threading.Thread(target=cium, args=(op.param1, op.param2)).start()
                    wait["mode"] = True

            if op.type == 13:
                if mid in op.param3:
                    cl.acceptGroupInvitation(op.param1)
                    if wait["autojoin"] == True:
                    	if op.param2 in Bots or op.param2 in wait["Owner"] or op.param2 in admin:
                    	    pass
                    	else:
                    	    user = cl.getContact(op.param2)
                    	    cl.sendMessage(op.param1,"Anda Bukan Termasuk ADMIN/STAF...\nBye.... \n\n\n\n#Kamibukanbotgratisan.." +str(user.displayName))
                    	    try:X = cl.getGroup(op.param1);X.name = str("FUCK YOU!!!");induk.updateGroup(X)
                    	    except:pass
                    	    cl.leaveGroup(op.param1)

            if op.type == 26:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 2:
                	if msg.toType == 0:
                	     to = msg._from
                	elif msg.toType == 2:
                	     to = msg.to
                	if msg.contentType == 0:
                	  if text is None:
                	      return
                	  else:
                	      cmd = command(text)
                	      if text.lower() == "sp":
                	             if msg._from in admin:
                	                 flash = threading.Thread(target=speedbot, args=(msg.to,)).start()

                	      elif text.lower() == "cuy":
                	             if msg._from in admin:
                	                 for bot in botlist:
                	                     bot.sendMessage(msg.to,"Ready ✅")
                    
                	      elif text.lower() == "out":
                	             if msg._from in admin:
                	                 for bot in botlist:
                	                     bot.leaveGroup(to)
                                                    
                	      elif text.lower() == ",":
                	             if msg._from in admin:
                	                 #if msg._from not in Bots:
                	                     try:G = cl.getGroup(to);G.preventedJoinByTicket = False;cl.updateGroup(G)
                	                     except:
                	                         try:
                	                             G = cl.getGroup(to)
                	                             G.name = str("😋")
                	                             G.preventedJoinByTicket = False
                	                             cl.updateGroup(G)
                	                         except:pass
                	                     Ticket = cl.reissueGroupTicket(to)
                	                     for army in botlist:
                	                         try:
                	                             army.acceptGroupInvitationByTicket(to, Ticket)
                	                         except:pass
                	                     G.preventedJoinByTicket = True
                	                     cl.updateGroup(G)

                	      elif text.lower() == "cb":
                	          if msg._from in admin:
                	              if wait["Blacklist"] == []:
                	                  cl.sendMessage(msg.to,"Tidak ada sampah")
                	              else:
                	                  mc = "[Daftar Sampah] "
                	                  num=1
                	                  ragets = cl.getContacts(wait["Blacklist"])
                	                  for mi_d in ragets:
                	                      mc+="\n%i. %s" % (num, mi_d.displayName)
                	                      num=(num+1)
                	                  mc+="\n\n [%i] Sampah Berhasil di Hapus ✅" % len(ragets)
                	                  cl.sendMessage(msg.to, mc)
                	                  wait["Blacklist"] = []
                	                  wait["mode"] = False

                	      elif text.lower() == "restart":
                	          if msg._from in admin:
                	              cl.sendMessage(msg.to,'system reboting..✅')
                	              restartBot()
                	      elif text.lower() == "lepall":
                	          if msg._from in admin:
                	              gid = cl.getGroupIdsJoined()
                	              for i in gid:
                	                  if i not in msg.to:
                	                      for bot in botlist:
                	                          bot.leaveGroup(i)
                	              cl.sendMessage(msg.to, 'done Bosqyu..')


                	      elif text.lower() == "xname":
                	          if msg._from in admin:
                	              a = cl.getProfile()
                	              a.displayName = str("1cok")
                	              cl.updateProfile(a)
                	              cl.sendMessage(msg.to,"✅")

                	      elif cmd == "gname":
                	          if msg._from in admin:
                	              G = cl.getGroup(to)
                	              G.name = str("••[TES-BOT]􀠁􀠁􂘁􀄌􀄌")
                	              cl.updateGroup(G)

                	      elif cmd == "lgn":
                	          if msg._from in admin:
                	              G = cl.getGroup(to)
                	              G.name = str(G.name+"􀠁􀠁􂘁􀄌􀄌󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳")
                	              cl.updateGroup(G)
                	              
                	      elif text.lower() == "cmd":
                	          if msg._from in admin:
                	              cl.sendMessage(msg.to,helpM)

                	      elif text.lower() == "cek bot":
                	          if msg._from in admin:
                	              bot1=True
                	              try:
                	                  cl.kickoutFromGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);bot1 = True
                	              except:bot1 = False
                	              md = "╭━━━━━━━━╮\n"
                	              md += "┃      Status Bot        ┃\n"
                	              md += "╰━━━━━━━━╯\n"
                	              if bot1 == True: md+="┃Bot1 😡 Ready\n╰━━━━━━━━╯"
                	              else: md+="┃Bot1 🤕 Meriang\n╰━━━━━━━━╯"
                	              cl.sendMessage(msg.to,md)

                	      elif cmd == "glist":
                	          #if wait["selfbot"] == True:
                	           if msg._from in admin:
                	               ma = ""
                	               a = 0
                	               gid = cl.getGroupIdsJoined()
                	               for i in gid:
                	                   G = cl.getGroup(i)
                	                   a = a + 1
                	                   end = "\n"
                	                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                	               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")


                	      elif cmd.startswith("openqr "):
                	          if msg._from in admin:
                	              separate = text.split(" ")
                	              number = text.replace(separate[0] + " ","")
                	              groups = cl.getGroupIdsJoined()
                	              ret_ = ""
                	              try:
                	                  group = groups[int(number)-1]
                	                  G = cl.getGroup(group)
                	                  G.preventedJoinByTicket = False
                	                  cl.updateGroup(G)
                	                  try:
                	                      gCreator = G.creator.mid
                	                      dia = cl.getContact(gCreator)
                	                      zx = ""
                	                      zxc = ""
                	                      zx2 = []
                	                      xpesan = '「 Sukses Open Qr 」\n• Creator :  '
                	                      diaa = str(dia.displayName)
                	                      pesan = ''
                	                      pesan2 = pesan+"@a\n"
                	                      xlen = str(len(zxc)+len(xpesan))
                	                      xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                	                      zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                	                      zx2.append(zx)
                	                      zxc += pesan2
                	                  except:
                	                      gCreator = "Tidak ditemukan"
                	                  if G.invitee is None:
                	                      gPending = "0"
                	                  else:
                	                      gPending = str(len(G.invitee))
                	                  if G.preventedJoinByTicket == True:
                	                      gQr = "Tertutup"
                	                      gTicket = "Tidak ada"
                	                  else:
                	                      gQr = "Terbuka"
                	                      gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                	                  timeCreated = []
                	                  timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                	                  #ret_ += xpesan+zxc
                	                  ret_ += "• Nama : {}".format(G.name)
                	                  ret_ += "\n• Group Qr : {}".format(gQr)
                	                  ret_ += "\n• Pendingan : {}".format(gPending)
                	                  ret_ += "\n• Group Ticket : {}".format(gTicket)
                	                  ret_ += ""
                	                  cl.sendMessage(msg.to,ret_)
                	              except:pass
                                

                	      elif cmd.startswith("gngc "):
                	          if msg._from in admin:
                	              txt = msg.text.split(" ")
                	              number = text.replace(txt[0] + " ","")
                	              string = str('VIP18++')
                	              groups = cl.getGroupIdsJoined()
                	              ret_ = ""
                	              try:
                	                  group = groups[int(number)-1]
                	                  #gname["group"] = str(cl.getGroup(group).name)
                	                  G = cl.getGroup(group)
                	                  G.name = str('VIP 12++')
                	                  cl.updateGroup(G)
                	                  #cl.getGroup(op.param1);X.name = str("VIP");cl.updateGroup(X)
                	                  ret_ += "• Di ganti menjadi : {}".format(G.name)
                	                  ret_ += ""
                	                  cl.sendMessage(msg.to,ret_)
                	              except Exception as e:print(e)


                	      elif cmd.startswith("gnbk "):
                	          if msg._from in admin:
                	              txt = msg.text.split(" ")
                	              number = text.replace(txt[0] + " ","")
                	              groups = cl.getGroupIdsJoined()
                	              ret_ = ""
                	              try:
                	                  group = groups[int(number)-1]
                	                  string = str(gname["group"])
                	                  G = cl.getGroup(group)
                	                  G.name = string
                	                  cl.updateGroup(G)
                	                  #cl.getGroup(op.param1);X.name = str("VIP");cl.updateGroup(X)
                	                  ret_ += "• Berahasil restore : {}".format(G.name)
                	                  ret_ += ""
                	                  cl.sendMessage(msg.to,ret_)
                	              except Exception as e:print(e)

                	      elif cmd.startswith("war "):
                	          if msg._from in admin:
                	              txt = msg.text.split(" ")
                	              number = text.replace(txt[0] + " ","")
                	              string = str('VIP18++')
                	              groups = cl.getGroupIdsJoined()
                	              ret_ = ""
                	              try:
                	                  group = groups[int(number)-1]
                	                  cl.sendMessage(group,"Tes kuy")
                	              except Exception as e:print(e)

                	      elif "Tium @" in msg.text:
                	         if msg._from in admin:
                	             nk0 = msg.text.replace("Tium @","")
                	             nk1 = nk0.lstrip()
                	             nk2 = nk1.replace("","")
                	             nk3 = nk2.rstrip()
                	             _name = nk3
                	             gs = cl.getGroup(msg.to)
                	             #targets = []
                	             for s in gs.members:
                	                 if _name in s.displayName:
                	                    #targets.append(s.mid)
                	                    wait["Blacklist"].append(s.mid)
                	             sleding = Thread(target=tium, args=(msg.to, wait["Blacklist"]))
                	             sleding.start()
                
                	      elif ("Cipok " in msg.text):
                	          if msg._from in admin:
                	              nk0 = msg.text.replace("Cipok ","")
                	              nk1 = nk0.lstrip()
                	              nk2 = nk1.replace("","")
                	              nk3 = nk2.lstrip()
                	              _name = nk3
                	              gs = cl.getGroup(msg.to)
                	              targets = []
                	              for s in gs.members:
                	                  if _name in s.displayName:
                	                     targets.append(s.mid)
                	              if targets == []:
                	                  cl.sendMessage(msg.to,'target tidak ada')
                	                  pass
                	              else:
                	                  for target in targets:
                	                      if target not in Bots:
                	                          try:cl.kickoutFromGroup(msg.to, target)
                	                          except:cl.sendMessage(msg.to,'em00h....')                	    

                	      elif ("Spam " in msg.text):
                	          if msg._from in admin:
                	              try:
                	                  text = msg.text.replace("Spin ","")
                	                  split = text.split(".")
                	                  namaGrup = split[1]
                	                  jmlh = 100
                	                  try:jmlh = int(split[2])
                	                  except:cl.sendMessage(msg.to,"Group Name Can't use spaces")
                	                  midd = split[3]
                	                  cl.findAndAddContactsByMid(midd)
                	                  try:
                	                      gas = Thread(target=spam, args=(msg.to,namaGrup,midd,jmlh))
                	                      gas.start()
                	                  except:pass
                	              except Exception as e:
                	                  cl.log("ERROR SPAM INV: "+str(e))


                	      elif cmd.startswith("gusur "):
                	          if msg._from in admin:
                	              separate = text.split(" ")
                	              number = text.replace(separate[0] + " ","")
                	              groups = cl.getGroupIdsJoined()
                	              ret_ = ""
                	              try:
                	                  group = groups[int(number)-1]
                	                  cl.sendMessage(msg.to,"Group "+cl.getGroup(group).name+"\nSegera di bersih kan!!")
                	                  cmd = 'dual.js gid={} token={} app={}'.format(group, cl.authToken, "CHROMEOS\t2.1.5\tDefrizal_OS\t1")
                	                  group = cl.getGroup(group)
                	                  members = [o.mid for o in group.members if o.mid not in admin]
                	                  for invitees in group.invitee:
                	                      cmd += ' uid={}'.format(invitees.mid)
                	                  for o in group.members:
                	                      if o.mid not in admin and o.mid not in Bots:
                	                          cmd += ' uik={}'.format(o.mid)
                	                  print(cmd)
                	                  success = execute_js(cmd)
                	                  cl.sendMessage(msg.to,"Group "+cl.getGroup(group).name+"\nBersih!!")
                	              except:pass

                	      elif "/ti/g/" in msg.text.lower():
                	          link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                	          links = link_re.findall(text)
                	          n_links = []
                	          for l in links:
                	             if l not in n_links:
                	                n_links.append(l)
                	          for ticket_id in n_links:
                	             group = cl.findGroupByTicket(ticket_id)
                	             cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                 
        except Exception as e:
            print(e)

def speedbot(grup):
	for bot in botlist:
		start = time.time()
		cl.sendMessage("ufd1fc96a20d7cf0a8e6e8dfc117f32be",'tes')
		elapsed_time = time.time() - start
		bot.sendMessage(grup, "%.6f" % (elapsed_time))
def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
def command(text):
        pesan = text.lower()
        if pesan.startswith(settings["keyCommand"]):
        	cmd = pesan.replace(settings["keyCommand"],"")
        else:
        	cmd = "command"
        return cmd
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)
def cium(grup, target):
    try:
        asd= cl.kickoutFromGroup(grup, [target])
        if asd != None:
            galaxyfail
    except:pass
    print("> galaxy ATTACK <")

def spam(grup,nama,mid,jmlh):
	try:
		while jmlh > 0:
			group = cl.createGroup(nama,[mid])
			group_id = group.id
			cl.leaveGroup(group_id)
			jmlh = jmlh - 1
		cl.sendMessage(grup,'sukses...')
	except:pass

def tium(grup, targets):
	if targets == []:
		pass
	else:
		for jembut in targets:
			if jembut not in Bots:
				try:
					cl.kickoutFromGroup(grup, [jembut])
				except:pass

def ccl(grup, targets):
	if targets == []:
		pass
	else:
		for jembut in targets:
			if jembut not in Bots:
				try:
					asd= cl.cancelGroupInvitation(grup, [jembut])
					if asd != None:
						galaxyfail
				except:pass
								        
def bkp(grup, target):
    try:
        gtb = [mid]
        cl.inviteIntoGroup(grup, gtb)
        if target == mid:
            acc1 = threading.Thread(target=cl.acceptGroupInvitation, args=(grup,)).start()
    except:
        try:
            gtb = [mid]
            cl.inviteIntoGroup(grup, gtb)
            if target == mid:
                acc7 = threading.Thread(target=cl.acceptGroupInvitation, args=(grup,)).start()
        except:
            pass
    print("invite")  

def bkpo(grup, target):
    try:
        cl.findAndAddContactsByMid(target)
        cl.inviteIntoGroup(grup, [target])
    except:
        pass
    print("invite")
def black(target):
    if target not in wait["Blacklist"] and target not in Bots and target not in admin:
        wait["Blacklist"].append(target)

def lockqr(grup):
    G = cl.getGroup(grup)
    G.preventedJoinByTicket = True
    try:
        asd= cl.updateGroup(G)
        if asd != None:
            galaxyfail
    except:pass

    print("NOTIF QR")
def lockunicode(grup):
    G = cl.getGroup(grup)
    settings["Gname"] = str(G.name)
    G.name = str('󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳??󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳')
    try:
        asd= cl.updateGroup(G)
        if asd != None:
            galaxyfail
    except:pass

    print("NOTIF Unicode")
while True:
	try:
		ops = oepoll.singleTrace(count=50)
		if ops != None:
			for op in ops:
				oepoll.setRevision(op.revision)
				flashbot = threading.Thread(target=bot, args=(op,))
				flashbot.deamon = True
				flashbot.start()
				#
	except Exception as e:
		print (e)
